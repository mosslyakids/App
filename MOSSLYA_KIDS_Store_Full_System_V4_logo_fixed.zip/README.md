# MOSSLYA KIDS - Corrected Flutter Project

This package contains the corrected MOSSLYA KIDS app source for the GitHub Actions APK build.

- Corrected TextEditingController initialization
- Includes product assets
- Includes http dependency used by the Razorpay-ready checkout scaffold
- No payment secrets or .env files are included


## V4 logo fix
The customer app now references `assets/branding/mosslya_kids_logo.png` explicitly and reserves a dedicated 250px header area for the full original logo artwork. Rebuild the APK after extracting this project.
