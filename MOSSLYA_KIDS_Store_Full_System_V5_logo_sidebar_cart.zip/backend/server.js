const http=require("http"),fs=require("fs"),path=require("path");
const PORT=process.env.PORT||3000,ADMIN_KEY=process.env.ADMIN_KEY||"CHANGE_ME_BEFORE_DEPLOY";
const DATA=path.join(__dirname,"data"),OF=path.join(DATA,"orders.json"),PF=path.join(DATA,"products.json"),ADMIN=path.join(__dirname,"admin","index.html");
const DEFAULT_PRODUCTS=[{id:"P001",name:"Butterfly T-Shirt & Shorts Set",price:549,stock:50},{id:"P002",name:"Giraffe & Elephant Baby Romper",price:599,stock:10},{id:"P003",name:"Floral Baby Romper",price:599,stock:10}];
const LOGO=path.join(__dirname,"..","assets","branding","mosslya_kids_logo.jpg");
if(!fs.existsSync(DATA))fs.mkdirSync(DATA,{recursive:true});
const read=(f,d)=>{try{return JSON.parse(fs.readFileSync(f,"utf8"))}catch(e){fs.writeFileSync(f,JSON.stringify(d,null,2));return d}};
const write=(f,d)=>fs.writeFileSync(f,JSON.stringify(d,null,2));
const json=(res,c,d)=>{res.writeHead(c,{"Content-Type":"application/json","Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type,X-Admin-Key","Access-Control-Allow-Methods":"GET,POST,PATCH,OPTIONS"});res.end(JSON.stringify(d));};
const body=req=>new Promise((ok,bad)=>{let s="";req.on("data",c=>s+=c);req.on("end",()=>{try{ok(s?JSON.parse(s):{})}catch(e){bad(e)}})});
const isAdmin=req=>req.headers["x-admin-key"]===ADMIN_KEY;
http.createServer(async(req,res)=>{if(req.method==="OPTIONS")return json(res,204,{});if(req.url==="/admin"||req.url==="/admin/"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8"});return res.end(fs.readFileSync(ADMIN))}if(req.url==="/branding/mosslya_kids_logo.jpg"){res.writeHead(200,{"Content-Type":"image/jpeg","Cache-Control":"public,max-age=86400"});return res.end(fs.readFileSync(LOGO))}if(req.url==="/health")return json(res,200,{ok:true,service:"mosslya-kids-backend"});try{
if(req.url==="/api/orders"&&req.method==="POST"){let b=await body(req),phone=String(b.phone||"").replace(/\D/g,"");if(phone.length!==10)return json(res,400,{error:"Valid 10-digit phone required"});let os=read(OF,[]);b.id=b.id||"MK"+Date.now();b.created_at=new Date().toISOString();os.unshift(b);write(OF,os);return json(res,201,{order:b})}
if(req.url==="/api/orders"&&req.method==="GET"){if(!isAdmin(req))return json(res,401,{error:"Unauthorized"});return json(res,200,{orders:read(OF,[])})}
if(req.url.startsWith("/api/orders/")&&req.method==="PATCH"){if(!isAdmin(req))return json(res,401,{error:"Unauthorized"});let id=decodeURIComponent(req.url.split("/").pop()),b=await body(req),os=read(OF,[]),i=os.findIndex(o=>o.id===id);if(i<0)return json(res,404,{error:"Not found"});os[i]={...os[i],...b,updated_at:new Date().toISOString()};write(OF,os);return json(res,200,{order:os[i]})}
if(req.url==="/api/products"&&req.method==="GET")return json(res,200,{products:read(PF,DEFAULT_PRODUCTS)});
return json(res,404,{error:"Not found"});}catch(e){console.error(e);return json(res,500,{error:"Server error"})}}).listen(PORT,()=>console.log("MOSSLYA KIDS backend listening on "+PORT));
