# MOSSLYA KIDS Full Store System V2

Includes the Flutter customer app, exact MOSSLYA KIDS logo, and a Node.js backend with an admin panel.

## Customer app
Use the gear icon on Home → Store Connection. After deploying the backend, paste its base URL, e.g. `https://your-backend.example.com` (example only). New orders are sent to `/api/orders` and are also kept locally.

## Admin panel
Deploy the `backend` folder. Set `ADMIN_KEY` to a strong secret. Open `/admin` on the deployed backend and log in with that key. You can view orders, customer mobile numbers, addresses, totals, and update order status.

## Important
This backend uses JSON files for prototype/testing. For production, use a managed database, HTTPS, proper authentication, backups, rate limiting, and persistent storage.
