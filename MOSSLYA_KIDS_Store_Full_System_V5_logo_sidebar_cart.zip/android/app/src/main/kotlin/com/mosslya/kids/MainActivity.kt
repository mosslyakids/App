package com.mosslya.kids

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
