# MOSSLYA KIDS Android project

This package includes the Android Gradle project files. The GitHub Actions workflow may regenerate Android platform files with the selected Flutter SDK before building, which is intentional and keeps the project compatible with the hosted Flutter toolchain.
