# MOSSLYA KIDS Bug-Fix Update

This build addresses the reported app issues:
- Mobile number field added at checkout for customer/order reference.
- Remove button added for each cart item.
- Cart count updates in the bottom navigation.
- Add to Cart now shows confirmation and a View Cart action.
- Product and Checkout screens have explicit back buttons.
- Checkout sends customer_phone to the backend create-order request.

The app remains a test build; Razorpay checkout still requires a configured backend.
