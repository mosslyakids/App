# MOSSLYA KIDS — Customer & Order System

This version adds persistent customer/order storage on the customer's Android device using SharedPreferences.

## Captured customer details
- Customer name
- 10-digit mobile number (required)
- Delivery address
- City
- 6-digit pincode

## Order details
- Unique Order ID (MK...)
- Date/time
- Products, sizes and quantities
- Total amount
- Status: Order placed

## Important limitation
This build stores order/customer information locally on the device. It does NOT create a shared cloud/admin database yet. For you to see customers/orders from your own phone or computer, the next step is to connect a secure backend/database API. Do not put Razorpay secrets or database passwords inside the APK.
