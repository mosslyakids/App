# MOSSLYA KIDS - Corrected Flutter Project

This package contains the corrected MOSSLYA KIDS app source for the GitHub Actions APK build.

- Corrected TextEditingController initialization
- Includes product assets
- Includes http dependency used by the Razorpay-ready checkout scaffold
- No payment secrets or .env files are included
