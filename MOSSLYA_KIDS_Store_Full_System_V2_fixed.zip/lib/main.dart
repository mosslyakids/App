import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const MosslyaKidsApp());

class Product {
  final String name, image, category;
  final int price;
  const Product(this.name, this.price, this.image, this.category);
}

const products = <Product>[
  Product('Butterfly T-Shirt & Shorts Set', 549, 'assets/products/product1.png', 'Sets'),
  Product('Giraffe & Elephant Baby Romper', 599, 'assets/products/product2.png', 'Rompers'),
  Product('Floral Baby Romper', 599, 'assets/products/product3.png', 'Rompers'),
  Product('Giraffe & Elephant Night Set', 699, 'assets/products/product4.png', 'Sets'),
  Product('Elephant & Stars Baby Waistcoat', 449, 'assets/products/product5.png', 'Babywear'),
  Product('Butterfly Print Girls Dress', 649, 'assets/products/product6.png', 'Dresses'),
  Product('Elephant & Garden Girls Dress', 649, 'assets/products/product7.png', 'Dresses'),
];

class CartItem {
  final Product product;
  final String size;
  int quantity;
  CartItem(this.product, this.size, {this.quantity = 1});
}

class OrderRecord {
  final String id, name, phone, address, city, pincode, date, status;
  final int total;
  OrderRecord({required this.id, required this.name, required this.phone, required this.address, required this.city, required this.pincode, required this.date, required this.status, required this.total});
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'phone': phone, 'address': address, 'city': city, 'pincode': pincode, 'date': date, 'status': status, 'total': total};
  factory OrderRecord.fromJson(Map<String, dynamic> j) => OrderRecord(id:j['id'], name:j['name'], phone:j['phone'], address:j['address'], city:j['city'], pincode:j['pincode'], date:j['date'], status:j['status'], total:j['total']);
}

class MosslyaKidsApp extends StatefulWidget {
  const MosslyaKidsApp({super.key});
  @override State<MosslyaKidsApp> createState() => _MosslyaKidsAppState();
}

class _MosslyaKidsAppState extends State<MosslyaKidsApp> {
  int tab = 0;
  final cart = <CartItem>[];
  final orders = <OrderRecord>[];
  String customerName = '', customerPhone = '', customerAddress = '', customerCity = '', customerPincode = '';
  String apiBaseUrl = '';

  @override void initState() { super.initState(); _loadData(); }

  Future<void> _loadData() async {
    final p = await SharedPreferences.getInstance();
    final savedOrders = p.getStringList('orders') ?? [];
    setState(() {
      customerName = p.getString('customer_name') ?? '';
      customerPhone = p.getString('customer_phone') ?? '';
      customerAddress = p.getString('customer_address') ?? '';
      customerCity = p.getString('customer_city') ?? '';
      customerPincode = p.getString('customer_pincode') ?? '';
      apiBaseUrl = p.getString('api_base_url') ?? '';
      orders.addAll(savedOrders.map((x) => OrderRecord.fromJson(jsonDecode(x))));
    });
  }

  Future<void> saveCustomer({required String name, required String phone, required String address, required String city, required String pincode}) async {
    final p = await SharedPreferences.getInstance();
    await Future.wait([
      p.setString('customer_name', name), p.setString('customer_phone', phone), p.setString('customer_address', address),
      p.setString('customer_city', city), p.setString('customer_pincode', pincode),
    ]);
    setState(() { customerName=name; customerPhone=phone; customerAddress=address; customerCity=city; customerPincode=pincode; });
  }

  Future<void> addToCart(Product product, String size) async {
    setState(() {
      final existing = cart.where((x) => x.product.name == product.name && x.size == size).toList();
      if (existing.isEmpty) cart.add(CartItem(product, size)); else existing.first.quantity++;
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${product.name} added to cart'), action: SnackBarAction(label:'VIEW CART', onPressed:()=>setState(()=>tab=2))));
  }

  void removeItem(int index) { setState(() => cart.removeAt(index)); }
  void changeQty(int index, int delta) { setState(() { cart[index].quantity += delta; if(cart[index].quantity<=0) cart.removeAt(index); }); }
  int get total => cart.fold(0, (s, x) => s + x.product.price*x.quantity);

  Future<String> createOrder({required String name, required String phone, required String address, required String city, required String pincode}) async {
    await saveCustomer(name:name, phone:phone, address:address, city:city, pincode:pincode);
    final items = cart.map((x)=>{'product':x.product.name,'size':x.size,'quantity':x.quantity,'unit_price':x.product.price}).toList();
    final id = 'MK${DateTime.now().millisecondsSinceEpoch.toString().substring(5)}';
    final order = OrderRecord(id:id,name:name,phone:phone,address:address,city:city,pincode:pincode,date:DateTime.now().toIso8601String(),status:'Order placed',total:total);
    final p = await SharedPreferences.getInstance();
    final base = apiBaseUrl.trim().replaceFirst(RegExp(r'/+$'), '');
    if (base.isNotEmpty) {
      final response = await http.post(Uri.parse('$base/api/orders'), headers:{'Content-Type':'application/json'}, body:jsonEncode({'id':id,'name':name,'phone':phone,'address':address,'city':city,'pincode':pincode,'date':order.date,'status':order.status,'total':total,'items':items})).timeout(const Duration(seconds:15));
      if(response.statusCode < 200 || response.statusCode >= 300) throw Exception('Server rejected order');
    }
    final all = [order, ...orders];
    await p.setStringList('orders', all.map((x)=>jsonEncode(x.toJson())).toList());
    setState(() { orders..clear()..addAll(all); cart.clear(); });
    return id;
  }

  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'MOSSLYA KIDS', theme:ThemeData(useMaterial3:true, colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFFB98F84)), scaffoldBackgroundColor:const Color(0xFFFFF8F2)),
    home: Scaffold(
      body: IndexedStack(index:tab, children:[Home(onAdd:addToCart,onSettings:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ApiSettings(initialUrl:apiBaseUrl,onSave:(url)async{final p=await SharedPreferences.getInstance();await p.setString('api_base_url',url);setState(()=>apiBaseUrl=url);})))), Shop(onAdd:addToCart), Cart(cart:cart,onRemove:removeItem,onQty:changeQty,onCheckout:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Checkout(initialName:customerName,initialPhone:customerPhone,initialAddress:customerAddress,initialCity:customerCity,initialPincode:customerPincode,total:total,onPlaceOrder:createOrder))))]),
      bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:[const NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),const NavigationDestination(icon:Icon(Icons.storefront_outlined),selectedIcon:Icon(Icons.storefront),label:'Shop'),NavigationDestination(icon:const Icon(Icons.shopping_bag_outlined),selectedIcon:const Icon(Icons.shopping_bag),label:'Cart${cart.isEmpty?'':' (${cart.length})'}')]),
    ),
  );
}

class Header extends StatelessWidget {
  final VoidCallback? onSettings;
  const Header({super.key,this.onSettings});
  @override Widget build(BuildContext c)=>Column(children:[
    if(onSettings!=null) Align(alignment:Alignment.topRight,child:IconButton(tooltip:'Store connection',icon:const Icon(Icons.settings_outlined),onPressed:onSettings)),
    Padding(padding:const EdgeInsets.fromLTRB(20,0,20,8),child:Image.asset('assets/branding/mosslya_kids_logo.jpg',height:170,fit:BoxFit.contain)),
  ]);
}

class Home extends StatelessWidget { final Future<void> Function(Product,String) onAdd; final VoidCallback onSettings; const Home({super.key,required this.onAdd,required this.onSettings}); @override Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[SliverToBoxAdapter(child:Header(onSettings:onSettings)),const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(16),child:Text('Little styles,\nbig little moments.',style:TextStyle(fontSize:28)))),const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.fromLTRB(20,8,20,12),child:Text('New Arrivals',style:TextStyle(fontSize:22,fontWeight:FontWeight.w600)))),SliverPadding(padding:const EdgeInsets.symmetric(horizontal:16),sliver:ProductGrid(items:products,onAdd:onAdd))])); }
class Shop extends StatelessWidget { final Future<void> Function(Product,String) onAdd; const Shop({super.key,required this.onAdd}); @override Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[const SliverToBoxAdapter(child:Header()),const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(20),child:Text('Shop',style:TextStyle(fontSize:26,fontWeight:FontWeight.w600)))),SliverPadding(padding:const EdgeInsets.symmetric(horizontal:16),sliver:ProductGrid(items:products,onAdd:onAdd))])); }
class ProductGrid extends StatelessWidget { final List<Product> items; final Future<void> Function(Product,String) onAdd; const ProductGrid({super.key,required this.items,required this.onAdd}); @override Widget build(BuildContext c)=>SliverGrid(gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:.66),delegate:SliverChildBuilderDelegate((c,i){final p=items[i];return Card(clipBehavior:Clip.antiAlias,child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ProductDetails(product:p,onAdd:onAdd))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Image.asset(p.image,width:double.infinity,fit:BoxFit.cover)),Padding(padding:const EdgeInsets.all(10),child:Text(p.name,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600))),Padding(padding:const EdgeInsets.fromLTRB(10,0,10,10),child:Text('₹${p.price}',style:const TextStyle(fontWeight:FontWeight.bold))) ]));},childCount:items.length)); }

class ProductDetails extends StatefulWidget { final Product product; final Future<void> Function(Product,String) onAdd; const ProductDetails({super.key,required this.product,required this.onAdd}); @override State<ProductDetails> createState()=>_ProductDetailsState(); }
class _ProductDetailsState extends State<ProductDetails> { String size='1–2Y'; bool added=false; @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Product'),leading:IconButton(icon:const Icon(Icons.arrow_back),onPressed:()=>Navigator.pop(c))),body:ListView(padding:const EdgeInsets.all(20),children:[ClipRRect(borderRadius:BorderRadius.circular(20),child:Image.asset(widget.product.image,height:340,fit:BoxFit.cover)),const SizedBox(height:18),Text(widget.product.name,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('₹${widget.product.price}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:14),Text('Category: ${widget.product.category}'),const SizedBox(height:18),const Text('Select Size',style:TextStyle(fontWeight:FontWeight.w600)),Wrap(spacing:7,children:['0–3M','3–6M','6–12M','1–2Y','2–3Y','3–4Y','4–5Y','5–6Y'].map((s)=>ChoiceChip(label:Text(s),selected:size==s,onSelected:(_)=>setState(()=>size=s))).toList()),const SizedBox(height:24),FilledButton.icon(onPressed:()async{await widget.onAdd(widget.product,size);setState(()=>added=true);},icon:Icon(added?Icons.check:Icons.add_shopping_cart),label:Text(added?'ADDED TO CART':'ADD TO CART'))])); }

class Cart extends StatelessWidget { final List<CartItem> cart; final void Function(int) onRemove; final void Function(int,int) onQty; final VoidCallback onCheckout; const Cart({super.key,required this.cart,required this.onRemove,required this.onQty,required this.onCheckout}); @override Widget build(BuildContext c){final total=cart.fold(0,(s,x)=>s+x.product.price*x.quantity);return SafeArea(child:Column(children:[const Header(),Expanded(child:cart.isEmpty?const Center(child:Text('Your cart is empty')):ListView.builder(itemCount:cart.length,itemBuilder:(c,i){final x=cart[i];return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(leading:Image.asset(x.product.image,width:55,fit:BoxFit.cover),title:Text(x.product.name),subtitle:Text('Size: ${x.size}\n₹${x.product.price} × ${x.quantity}'),isThreeLine:true,trailing:SizedBox(width:100,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Row(mainAxisAlignment:MainAxisAlignment.end,children:[IconButton(icon:const Icon(Icons.remove_circle_outline),onPressed:()=>onQty(i,-1)),Text('${x.quantity}'),IconButton(icon:const Icon(Icons.add_circle_outline),onPressed:()=>onQty(i,1))]),Align(alignment:Alignment.centerRight,child:IconButton(tooltip:'Remove item',icon:const Icon(Icons.delete_outline),onPressed:()=>onRemove(i))) ]))));})),if(cart.isNotEmpty)Padding(padding:const EdgeInsets.all(16),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Total',style:TextStyle(fontSize:18)),Text('₹$total',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))]),const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton(onPressed:onCheckout,child:const Text('PROCEED TO CHECKOUT')))]))]));}}

class ApiSettings extends StatefulWidget { final String initialUrl; final Future<void> Function(String) onSave; const ApiSettings({super.key,required this.initialUrl,required this.onSave}); @override State<ApiSettings> createState()=>_ApiSettingsState(); }
class _ApiSettingsState extends State<ApiSettings>{late final TextEditingController c; String msg=''; @override void initState(){super.initState();c=TextEditingController(text:widget.initialUrl);} @override void dispose(){c.dispose();super.dispose();} Future<void> save()async{final url=c.text.trim().replaceFirst(RegExp(r'/+$'),''); await widget.onSave(url); if(mounted)setState(()=>msg=url.isEmpty?'Online orders disabled.':'Store API saved.');} @override Widget build(BuildContext x)=>Scaffold(appBar:AppBar(title:const Text('Store Connection'),leading:IconButton(icon:const Icon(Icons.arrow_back),onPressed:()=>Navigator.pop(x))),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('API URL',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),const Text('Paste your deployed MOSSLYA KIDS backend URL here.'),const SizedBox(height:16),TextField(controller:c,keyboardType:TextInputType.url,decoration:const InputDecoration(labelText:'Backend API URL',hintText:'https://your-api.example.com',border:OutlineInputBorder())),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:save,child:const Text('SAVE API URL'))),if(msg.isNotEmpty)Padding(padding:const EdgeInsets.only(top:12),child:Text(msg)),const SizedBox(height:20),const Text('When an API URL is saved, new orders are sent to your online admin backend.'))]))); }

class Checkout extends StatefulWidget { final String initialName,initialPhone,initialAddress,initialCity,initialPincode; final int total; final Future<String> Function({required String name,required String phone,required String address,required String city,required String pincode}) onPlaceOrder; const Checkout({super.key,required this.initialName,required this.initialPhone,required this.initialAddress,required this.initialCity,required this.initialPincode,required this.total,required this.onPlaceOrder}); @override State<Checkout> createState()=>_CheckoutState(); }
class _CheckoutState extends State<Checkout>{late final TextEditingController name,phone,address,city,pincode;bool busy=false;String error='';@override void initState(){super.initState();name=TextEditingController(text:widget.initialName);phone=TextEditingController(text:widget.initialPhone);address=TextEditingController(text:widget.initialAddress);city=TextEditingController(text:widget.initialCity);pincode=TextEditingController(text:widget.initialPincode);}@override void dispose(){name.dispose();phone.dispose();address.dispose();city.dispose();pincode.dispose();super.dispose();}Future<void> place()async{final ph=phone.text.replaceAll(RegExp(r'\D'),'');if(name.text.trim().isEmpty||ph.length!=10||address.text.trim().isEmpty||city.text.trim().isEmpty||pincode.text.trim().length!=6){setState(()=>error='Please enter name, valid 10-digit mobile number, complete address, city and 6-digit pincode.');return;}setState(()=>busy=true);try{final id=await widget.onPlaceOrder(name:name.text.trim(),phone:ph,address:address.text.trim(),city:city.text.trim(),pincode:pincode.text.trim());if(!mounted)return;showDialog(context:context,barrierDismissible:false,builder:(_)=>AlertDialog(title:const Text('Order placed successfully'),content:Text('Order ID: $id\n\nCustomer mobile saved for future reference.'),actions:[TextButton(onPressed:(){Navigator.pop(context);Navigator.pop(context);},child:const Text('DONE'))]));}catch(e){setState(()=>error='Could not save the order. Please try again.');}finally{if(mounted)setState(()=>busy=false);}}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Customer & Checkout'),leading:IconButton(icon:const Icon(Icons.arrow_back),onPressed:()=>Navigator.pop(c))),body:ListView(padding:const EdgeInsets.all(20),children:[Text('Order total: ₹${widget.total}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),const SizedBox(height:18),field(name,'Customer name',Icons.person_outline),field(phone,'Mobile number *',Icons.phone_outlined,keyboard:TextInputType.phone),field(address,'Delivery address *',Icons.home_outlined,maxLines:3),field(city,'City *',Icons.location_city),field(pincode,'Pincode *',Icons.pin_drop_outlined,keyboard:TextInputType.number),if(error.isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:12),child:Text(error,style:TextStyle(color:Theme.of(c).colorScheme.error))),const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:busy?null:place,icon:const Icon(Icons.check_circle_outline),label:Text(busy?'SAVING ORDER...':'PLACE ORDER'))),const SizedBox(height:10),const Text('Your customer details are stored on this device for future reference. A secure online database/API is still required if you want to access orders from another phone or computer.') ]));}
Widget field(TextEditingController x,String label,IconData icon,{TextInputType? keyboard,int maxLines=1})=>Padding(padding:const EdgeInsets.only(bottom:12),child:TextField(controller:x,keyboardType:keyboard,maxLines:maxLines,decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon),border:const OutlineInputBorder())));
