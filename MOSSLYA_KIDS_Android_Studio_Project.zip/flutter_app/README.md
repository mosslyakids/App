# MOSSLYA KIDS — V1.1 Razorpay-ready scaffold

This version is intentionally independent of the previously uploaded .env file.

Included:
- Flutter customer catalogue/cart
- Product images supplied in chat
- Checkout screen
- Secure architecture scaffold: mobile app calls your backend to create a Razorpay order
- No Razorpay secret embedded in the app

To finish real test payments:
1. Create your own Razorpay test account/keys.
2. Put the Key ID and Key Secret ONLY on your backend as environment variables.
3. Implement POST /api/payments/create-order on the backend using Razorpay Orders API.
4. Return order_id, amount and currency to the app.
5. Add the Razorpay Flutter checkout package and open checkout with the returned order_id.
6. Verify the payment signature on the backend.
7. Add a webhook endpoint for authoritative payment/order status updates.

This scaffold does not claim a payment is successful merely because an order was created.
