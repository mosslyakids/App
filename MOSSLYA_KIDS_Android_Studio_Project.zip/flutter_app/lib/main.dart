import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const MosslyaKidsApp());

class Product {
  final String name, image, category;
  final int price;
  const Product(this.name,this.price,this.image,this.category);
}

const products = [
  Product('Butterfly T-Shirt & Shorts Set',549,'assets/products/product1.png','Sets'),
  Product('Giraffe & Elephant Baby Romper',599,'assets/products/product2.png','Rompers'),
  Product('Floral Baby Romper',599,'assets/products/product3.png','Rompers'),
  Product('Giraffe & Elephant Night Set',699,'assets/products/product4.png','Sets'),
  Product('Elephant & Stars Baby Waistcoat',449,'assets/products/product5.png','Babywear'),
  Product('Butterfly Print Girls Dress',649,'assets/products/product6.png','Dresses'),
  Product('Elephant & Garden Girls Dress',649,'assets/products/product7.png','Dresses'),
];

class MosslyaKidsApp extends StatefulWidget {
  const MosslyaKidsApp({super.key});
  @override State<MosslyaKidsApp> createState()=>_AppState();
}
class _AppState extends State<MosslyaKidsApp>{
  int tab=0; final cart=<Product>[];
  void add(Product p){setState(()=>cart.add(p)); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${p.name} added to cart')));}
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'MOSSLYA KIDS',
    theme:ThemeData(useMaterial3:true,scaffoldBackgroundColor:const Color(0xFFFFF8F2),
      colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFFB98F84)),fontFamily:'Georgia'),
    home:Scaffold(body:IndexedStack(index:tab,children:[
      Home(onAdd:add), Shop(onAdd:add), Cart(cart:cart)
    ]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),
        NavigationDestination(icon:Icon(Icons.storefront_outlined),label:'Shop'),
        NavigationDestination(icon:Icon(Icons.shopping_bag_outlined),label:'Cart')
      ])));
}

class Header extends StatelessWidget{
  const Header({super.key});
  @override Widget build(BuildContext c)=>const Padding(
    padding:EdgeInsets.fromLTRB(20,18,20,8),
    child:Column(children:[
      Text('MOSSLYA',style:TextStyle(fontSize:31,letterSpacing:7)),
      Text('K I D S',style:TextStyle(fontSize:13,letterSpacing:6,color:Color(0xFFB98579))),
      SizedBox(height:5),Text('CLOTHING FOR LITTLE MOMENTS',style:TextStyle(fontSize:9,letterSpacing:2.2))
    ]));
}

class Home extends StatelessWidget{
  final void Function(Product) onAdd; const Home({super.key,required this.onAdd});
  @override Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[
    const SliverToBoxAdapter(child:Header()),
    const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(16),child:Text('Little styles,\\nbig little moments.',style:TextStyle(fontSize:28)))),
    const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.fromLTRB(20,8,20,12),child:Text('New Arrivals',style:TextStyle(fontSize:22,fontWeight:FontWeight.w600)))),
    SliverPadding(padding:const EdgeInsets.symmetric(horizontal:16),sliver:Grid(products,onAdd))
  ]));
}
class Shop extends StatelessWidget{
  final void Function(Product) onAdd; const Shop({super.key,required this.onAdd});
  @override Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[
    const SliverToBoxAdapter(child:Header()),
    const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(20),child:Text('Shop',style:TextStyle(fontSize:26,fontWeight:FontWeight.w600)))),
    SliverPadding(padding:const EdgeInsets.symmetric(horizontal:16),sliver:Grid(products,onAdd))
  ]));
}
class Grid extends StatelessWidget{
  final List<Product> ps; final void Function(Product) add;
  const Grid(this.ps,this.add,{super.key});
  @override Widget build(BuildContext c)=>SliverGrid(delegate:SliverChildBuilderDelegate(
    (_,i)=>Card(color:Colors.white,elevation:0,clipBehavior:Clip.antiAlias,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18)),
      child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Details(product:ps[i],onAdd:add))),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Expanded(child:Image.asset(ps[i].image,width:double.infinity,fit:BoxFit.cover)),
          Padding(padding:const EdgeInsets.fromLTRB(10,8,10,2),child:Text(ps[i].name,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w600))),
          Row(children:[Padding(padding:const EdgeInsets.only(left:10),child:Text('₹${ps[i].price}',style:const TextStyle(fontWeight:FontWeight.bold))),
            const Spacer(),IconButton(onPressed:()=>add(ps[i]),icon:const Icon(Icons.add_shopping_cart,size:20))])
        ]))),childCount:ps.length),
    gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:14,childAspectRatio:.68));
}
class Details extends StatefulWidget{
  final Product product; final void Function(Product) onAdd;
  const Details({super.key,required this.product,required this.onAdd});
  @override State<Details> createState()=>_DetailsState();
}
class _DetailsState extends State<Details>{
  String size='1–2Y';
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Product')),body:ListView(children:[
    Image.asset(widget.product.image,height:430,fit:BoxFit.cover),
    Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(widget.product.name,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w600)),
      const SizedBox(height:8),Text('₹${widget.product.price}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:15),const Text('100% Muslin',style:TextStyle(fontSize:16)),const Text('Age: 0–3 years',style:TextStyle(fontSize:16)),
      const SizedBox(height:18),const Text('Select Size',style:TextStyle(fontWeight:FontWeight.w600)),
      Wrap(spacing:7,children:['0–3M','3–6M','6–12M','1–2Y','2–3Y'].map((s)=>ChoiceChip(label:Text(s),selected:size==s,onSelected:(_)=>setState(()=>size=s))).toList()),
      const SizedBox(height:24),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>widget.onAdd(widget.product),child:const Text('ADD TO CART')))
    ]))
  ]));
}

class Cart extends StatelessWidget{
  final List<Product> cart; const Cart({super.key,required this.cart});
  @override Widget build(BuildContext c){
    final total=cart.fold<int>(0,(a,p)=>a+p.price);
    return SafeArea(child:Column(children:[
      const Header(),Expanded(child:cart.isEmpty?const Center(child:Text('Your cart is empty')):ListView.builder(itemCount:cart.length,itemBuilder:(_,i)=>ListTile(
        leading:Image.asset(cart[i].image,width:55,fit:BoxFit.cover),title:Text(cart[i].name),trailing:Text('₹${cart[i].price}')))),
      if(cart.isNotEmpty)Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Total',style:TextStyle(fontSize:18)),Text('₹$total',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))]),
        const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>Checkout(amount:total))),child:const Text('PROCEED TO CHECKOUT')))
      ]))
    ]));
  }
}

class Checkout extends StatefulWidget{
  final int amount; const Checkout({super.key,required this.amount});
  @override State<Checkout> createState()=>_CheckoutState();
}
class _CheckoutState extends State<Checkout>{
  final api=TextEditingController(text='https://YOUR-API-DOMAIN.com');
  bool busy=false; String message='';
  Future<void> createOrder() async {
    setState(()=>busy=true);
    try{
      final url=Uri.parse('${api.text.trim()}/api/payments/create-order');
      final r=await http.post(url,headers:{'Content-Type':'application/json'},
        body:jsonEncode({'amount':widget.amount*100,'currency':'INR','receipt':'mosslya_demo'}));
      if(r.statusCode>=200&&r.statusCode<300){
        setState(()=>message='Razorpay order created. Next connect the Razorpay checkout SDK using the returned order_id.');
      }else{setState(()=>message='Backend returned ${r.statusCode}. Check your API and Razorpay test configuration.');}
    }catch(e){setState(()=>message='Could not reach the backend. Set your API URL first.');}
    setState(()=>busy=false);
  }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Checkout')),body:Padding(
    padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Order total: ₹${widget.amount}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:18),const Text('Backend API URL'),
      TextField(controller:api,decoration:const InputDecoration(hintText:'https://api.example.com')),
      const SizedBox(height:18),const Text('Razorpay is intentionally kept server-side. Never place the Key Secret in this app.'),
      const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:createOrder,child:Text(busy?'Creating order...':'CREATE TEST RAZORPAY ORDER'))),
      const SizedBox(height:18),Text(message)
    ])));
}
