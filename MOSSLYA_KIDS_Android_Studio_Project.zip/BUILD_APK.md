# MOSSLYA KIDS — Android Studio / Flutter Project

## Build an APK on a computer

1. Install Flutter SDK and Android Studio.
2. Open the `flutter_app` folder in Android Studio/VS Code.
3. In a terminal inside `flutter_app`, run:
   `flutter pub get`
4. Connect an Android phone with USB debugging enabled, or start an Android emulator.
5. Run:
   `flutter run`
6. To make an installable release APK:
   `flutter build apk --release`
7. The APK will be generated under:
   `build/app/outputs/flutter-apk/app-release.apk`

## Important
This project does NOT contain the Razorpay secret. The checkout scaffold calls a backend endpoint. Add your own Razorpay test credentials only on your backend, never in the mobile app.

This package is source code. An APK has not been generated in this environment because the Android/Flutter build toolchain is unavailable here.
